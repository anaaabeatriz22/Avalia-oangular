import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ContaService {

  private saldo: number = 0;

  constructor() { }

  // Crie aqui um método para depositar um valor na conta



  // Crie aqui um método para sacar um valor da conta
}
